import StarshipsPage from './starships-page';

export default StarshipsPage;
