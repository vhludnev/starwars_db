import PersonDetails from './item-details';

export default PersonDetails;
