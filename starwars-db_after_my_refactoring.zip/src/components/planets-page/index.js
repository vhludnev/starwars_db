import PlanetsPage from './planets-page';

export default PlanetsPage;
